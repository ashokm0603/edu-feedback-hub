import React, { useState } from "react";

// Star rating component
const StarRating = ({ rating, setRating, maxStars = 5 }) => {
  return (
    <div className="star-rating">
      {[...Array(maxStars)].map((_, index) => {
        const starValue = index + 1;
        return (
          <span
            key={starValue}
            className="star"
            onClick={() => setRating(starValue)}
            style={{ cursor: "pointer" }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="30"
              height="30"
              viewBox="0 0 24 24"
              fill={starValue <= rating ? "#ffd700" : "#ddd"}
              style={
                starValue <= rating ? { boxShadow: "5px 5px 5px black" } : {}
              }
            >
              <path d="M12 0l3.09 6.26L22 7.27l-5 4.87 1.18 6.88L12 16l-6.18 3.02L7 12.14 2 7.27l6.91-1.01L12 0z" />
            </svg>
          </span>
        );
      })}
    </div>
  );
};

const FirstYear_1_1_CSE = () => {
  const subjects = [
    "LINEAR ALGEBRA & CALCULUS",
    "BASIC CIVIL & MECHANICAL ENGINEERING",
    "CHEMISTRY",
    "COMPUTER PROGRAMMING",
    "COMMUNICATIVE ENGLISH",
    "CP LAB",
    "BCME LAB",
    "ENGLISH LAB",
    "CHEMISTRY LAB",

  ];



  const ratings = ["Excellent", "Very Good", "Good", "Fair", "Poor"];
  const labratings = [
    "Experiments explained during Lab?",
    "Experiments Executed in Lab?",
    "Observation and Record corrected?",
  ];


  // State management
  const [subjectRatings, setSubjectRatings] = useState({});
  const [overallRating, setOverallRating] = useState(0);
  const [suggestions, setSuggestions] = useState("");

  // Handle subject rating change
  const handleSubjectRating = (subject, rating) => {
    setSubjectRatings((prev) => ({
      ...prev,
      [subject]: rating,
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({
      subjectRatings,
      overallRating,
      suggestions,
    });
  };

  // Clear form
  const handleClear = () => {
    setSubjectRatings({});
    setOverallRating(0);
    setSuggestions("");
  };

  return (
    <div className="form-container">
      <div>
        <img src="image.png" alt="" />
      </div>
      <div className="form-header">
        <h2>RVIT - Student Feedback Form</h2>
      </div>
      <div className="form-header2">
        <p>
          Dear 1-1 CSE Students, Please provide your Feedback by giving
          rating(on scale of Excellent to Poor) for each Subject.
        </p>
        <ul>
          <li>
            <span>*Note:</span> The Information Provided by you will be
            <span> Confidential</span>.
          </li>
        </ul>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Subject Ratings Table */}
        <table className="rating-table" id="rating-table-container">
          <thead>
            <tr>
              <th>Subject</th>
              {ratings.map((rating) => (
                <th key={rating}>{rating}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {subjects.map((subject) => (
              <>
                <tr key={subject} style={{ marginTop: "10px" }}>
                  <td>{subject}</td>
                  {ratings.map((rating) => (
                    <td key={`${subject}-${rating}`}>
                      <input
                        type="radio"
                        className="radio-input"
                        name={subject}
                        checked={subjectRatings[subject] === rating}
                        onChange={() => handleSubjectRating(subject, rating)}
                      />
                    </td>
                  ))}
                </tr>
                <tr></tr>
              </>
            ))}
          </tbody>
        </table>
        {/* Overall Experience */}
        <div className="overall-rating">
          <h2>Overall Academic Experience</h2>
          <div className="rating-scale">
            <StarRating
              rating={overallRating}
              setRating={setOverallRating}
              maxStars={5}
            />
          </div>
        </div>

        {/* Suggestions */}
        <div className="suggestions">
          <h2>Suggestions/Recommendations</h2>
          <textarea
            className="suggestions-box"
            value={suggestions}
            placeholder="Your Answer...."
            onChange={(e) => setSuggestions(e.target.value)}
          />
        </div>

        {/* Form Buttons */}
        <div className="form-buttons">
          <button type="button" className="clear-btn" onClick={handleClear}>
            Clear Form
          </button>
          <button type="submit" className="submit-btn">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default FirstYear_1_1_CSE;
